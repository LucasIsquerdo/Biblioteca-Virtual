# ES2---BSI
Trabalho de Engenharia 2 - Implementações

Implementação do projeto semestral de uma biblioteca - Library Tree.
Composição do código: Java 8, Spring Data/JPA, JavaScript, HTML/CSS, Bootstrap

- Funções Fundamentais:
  - Arthur : Registrar Suspensão
  - José Renato : Registrar entrada de exemplares
  - Karolaine: Emprestar livros
  - Lucas : Devolver livros
 
 - Funções básicas:
    - Arthur: Gerenciar títulos
    - José Renato: Login
    - Karolaine: Gerenciar editoras
    - Lucas: Parametrização
