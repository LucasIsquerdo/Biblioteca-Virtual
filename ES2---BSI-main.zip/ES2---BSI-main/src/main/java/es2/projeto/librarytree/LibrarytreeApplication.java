package es2.projeto.librarytree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarytreeApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibrarytreeApplication.class, args);
    }

}

