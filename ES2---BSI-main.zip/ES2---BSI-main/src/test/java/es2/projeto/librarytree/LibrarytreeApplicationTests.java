package es2.projeto.librarytree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarytreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
